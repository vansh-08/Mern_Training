export interface UserI {
    name: string;
    age: number;
    gender: string;
    dob: string;
    hobbies: string;
    id?: string;
}